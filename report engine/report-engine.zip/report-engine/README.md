# Bluewright Monthly Report Engine

Um motor, um YAML por cliente. Pull direto GA4 + HubSpot + Meta → PDF (identidade
Bluewright) + Excel → envio por email com bloqueio de qualidade.

## Setup (uma vez, no VPS)

```bash
pip install weasyprint jinja2 matplotlib xlsxwriter pyyaml pandas requests google-analytics-data
# WeasyPrint precisa de libs de sistema: apt install libpango-1.0-0 libpangocairo-1.0-0
```

## Onboarding de um cliente novo (~30 min)

1. Copiar `config/conceptance.example.yaml` → `config/<cliente>.yaml`
2. **GA4**: criar service account no Google Cloud, guardar o JSON em `secrets/`,
   adicionar o email da SA como *Viewer* na property GA4 do cliente
3. **HubSpot**: private app no portal do cliente (scopes `crm.objects.contacts.read`,
   `crm.objects.deals.read`), token para variável de ambiente
4. **Meta**: system user token de longa duração, idem
5. Testar: `python3 report_engine.py --config config/<cliente>.yaml --no-send`
6. Cron: `0 7 2 * * cd /opt/report-engine && python3 report_engine.py --config config/<cliente>.yaml`

## Operação

| Comando | Efeito |
|---|---|
| `--dry-run` | dados sintéticos, sem envio — demos e testes de template |
| `--no-send` | dados reais, grava em disco, não envia |
| `--period 2026-06` | mês específico (default: mês anterior) |
| `--commentary "..."` | nota do consultor no fim do PDF |

## Salvaguardas

- **`delivery.mode: review`** (default) envia só para ti. Mudar para `client`
  apenas após 2–3 ciclos sem surpresas.
- **Staleness**: se uma fonte não tiver dados nos últimos `staleness_max_days`
  dias do período, o relatório é gravado com aviso mas o envio é **bloqueado**
  (exit code 2 — visível no log do cron). Foi exatamente o caso do token Meta
  da Conceptance parado desde junho.

## Nota do consultor

O `--commentary` é o que diferencia isto de um dashboard automático: 2–3 frases
tuas por cliente por mês. É trabalho de 10 minutos que justifica o fee recorrente.

## Estrutura

```
report_engine.py       orquestração, staleness, render, envio
fetchers/live.py       GA4 Data API, HubSpot CRM API, Meta Graph API
fetchers/sample.py     dados sintéticos (dry-run, demos comerciais)
charts.py              matplotlib → PNG base64 (paleta navy/brass/steel)
templates/report.html.j2   Jinja2 → WeasyPrint
config/<cliente>.yaml  um por cliente
outputs/<cliente>/<YYYY-MM>/   PDF + XLSX gerados
```
