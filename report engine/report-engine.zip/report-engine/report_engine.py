#!/usr/bin/env python3
"""Bluewright Monthly Report Engine.

Um motor, um YAML por cliente.

Uso:
  python3 report_engine.py --config config/cliente.yaml            # mês anterior
  python3 report_engine.py --config config/cliente.yaml --period 2026-06
  python3 report_engine.py --config config/cliente.yaml --dry-run  # dados sintéticos, sem envio
  python3 report_engine.py --config config/cliente.yaml --commentary "Texto do consultor..."
"""
from __future__ import annotations

import argparse
import os
import smtplib
import sys
from email.message import EmailMessage
from pathlib import Path

import pandas as pd
import yaml
from jinja2 import Environment, FileSystemLoader

import charts

BASE = Path(__file__).resolve().parent

LABELS = {
    "pt": {
        "title": "Relatório Mensal", "web": "Website — GA4", "crm": "Comercial — HubSpot",
        "paid": "Meta Ads", "channels": "Canais de aquisição", "top_pages": "Páginas mais vistas",
        "sessions": "Sessões", "users": "Utilizadores", "pageviews": "Visualizações",
        "new_contacts": "Novos contactos", "deals_created": "Deals criados",
        "deals_won": "Deals ganhos", "won_value": "Valor ganho",
        "spend": "Investimento", "impressions": "Impressões", "clicks": "Cliques",
        "campaign": "Campanha", "page": "Página", "views": "Visualizações",
        "prev_month": "Mês anterior", "this_month": "Este mês", "commentary": "Nota do consultor",
        "vs_prev": "vs mês anterior",
        "stale": "Fonte {src} sem dados desde {d} — valores possivelmente incompletos.",
    },
    "en": {
        "title": "Monthly Report", "web": "Website — GA4", "crm": "Sales — HubSpot",
        "paid": "Meta Ads", "channels": "Acquisition channels", "top_pages": "Top pages",
        "sessions": "Sessions", "users": "Users", "pageviews": "Pageviews",
        "new_contacts": "New contacts", "deals_created": "Deals created",
        "deals_won": "Deals won", "won_value": "Won value",
        "spend": "Spend", "impressions": "Impressions", "clicks": "Clicks",
        "campaign": "Campaign", "page": "Page", "views": "Views",
        "prev_month": "Previous month", "this_month": "This month", "commentary": "Consultant note",
        "vs_prev": "vs previous month",
        "stale": "Source {src} has no data since {d} — figures may be incomplete.",
    },
}

MONTHS_PT = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho",
             "agosto", "setembro", "outubro", "novembro", "dezembro"]


# ── período ────────────────────────────────────────────────────────
def resolve_period(arg: str | None):
    if arg:
        start = pd.Timestamp(f"{arg}-01")
    else:
        today = pd.Timestamp.today().normalize()
        start = (today.replace(day=1) - pd.DateOffset(months=1))
    end = start + pd.offsets.MonthEnd(0)
    return start, end


def period_label(start: pd.Timestamp, lang: str) -> str:
    if lang == "pt":
        return f"{MONTHS_PT[start.month - 1].capitalize()} {start.year}"
    return start.strftime("%B %Y")


# ── kpi macro para o template ──────────────────────────────────────
def kpi_html(branding):
    def _fmt(v, money):
        if money:
            return f"€{v:,.0f}".replace(",", " ")
        return f"{v:,.0f}".replace(",", " ")

    def kpi(label, value, prev=None, money=False, accent=False):
        delta = ""
        if prev not in (None, 0):
            pct = (value - prev) / prev * 100
            cls = "up" if pct > 1 else ("down" if pct < -1 else "flat")
            arrow = "▲" if pct > 1 else ("▼" if pct < -1 else "◆")
            delta = f'<div class="delta {cls}">{arrow} {pct:+.1f}%</div>'
        acc = " accent" if accent else ""
        return (f'<div class="kpi{acc}"><div class="value">{_fmt(value, money)}</div>'
                f'<div class="label">{label}</div>{delta}</div>')
    return kpi


# ── excel ──────────────────────────────────────────────────────────
def build_excel(path: Path, data: dict, t: dict):
    import xlsxwriter
    wb = xlsxwriter.Workbook(str(path))
    hdr = wb.add_format({"bold": True, "font_color": "white", "bg_color": "#12263A", "border": 0})
    num = wb.add_format({"num_format": "#,##0"})
    money = wb.add_format({"num_format": "€#,##0.00"})

    def sheet(name, df, money_cols=()):
        ws = wb.add_worksheet(name[:31])
        for c, col in enumerate(df.columns):
            ws.write(0, c, str(col), hdr)
            width = max(12, df[col].astype(str).str.len().max() + 2)
            ws.set_column(c, c, min(width, 48), money if col in money_cols else
                          (num if pd.api.types.is_numeric_dtype(df[col]) else None))
        for r, (_, row) in enumerate(df.iterrows(), start=1):
            for c, v in enumerate(row):
                ws.write(r, c, v.strftime("%Y-%m-%d") if isinstance(v, pd.Timestamp) else v)

    if data.get("ga4"):
        sheet("GA4 diario", data["ga4"]["daily_sessions"])
        sheet(t["channels"], data["ga4"]["channels"])
        sheet(t["top_pages"], data["ga4"]["top_pages"])
    if data.get("hubspot"):
        sheet("HubSpot", data["hubspot"]["funnel"])
    if data.get("meta"):
        sheet("Meta Ads", data["meta"]["campaigns"], money_cols=("spend", "cpc"))
    wb.close()


# ── envio ──────────────────────────────────────────────────────────
def send_email(cfg: dict, subject: str, body: str, attachments: list[Path], to: list[str], cc: list[str]):
    smtp = cfg["delivery"]["smtp"]
    msg = EmailMessage()
    msg["From"] = smtp["from"]
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg.set_content(body)
    for p in attachments:
        ctype = ("application/pdf" if p.suffix == ".pdf"
                 else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        maintype, subtype = ctype.split("/")
        msg.add_attachment(p.read_bytes(), maintype=maintype, subtype=subtype, filename=p.name)
    with smtplib.SMTP(smtp["host"], smtp["port"]) as s:
        s.starttls()
        s.login(os.environ[smtp["user_env"]], os.environ[smtp["password_env"]])
        s.send_message(msg)


# ── main ───────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--period", help="YYYY-MM (default: mês anterior)")
    ap.add_argument("--dry-run", action="store_true", help="dados sintéticos, sem envio")
    ap.add_argument("--no-send", action="store_true", help="dados reais, mas só grava em disco")
    ap.add_argument("--commentary", default="", help="nota do consultor incluída no PDF")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    lang = cfg["client"].get("language", "pt")
    t = LABELS[lang]
    start, end = resolve_period(args.period)
    plabel = period_label(start, lang)
    period_key = start.strftime("%Y-%m")
    print(f"[{cfg['client']['id']}] período: {plabel}")

    # 1. fetch
    if args.dry_run:
        from fetchers import sample
        data = sample.fetch_all(start, end)
    else:
        from fetchers import live
        data = {}
        src = cfg["sources"]
        if src.get("ga4", {}).get("enabled"):
            data["ga4"] = live.fetch_ga4(src["ga4"], start.date(), end.date())
        if src.get("hubspot", {}).get("enabled"):
            data["hubspot"] = live.fetch_hubspot(src["hubspot"], start.date(), end.date())
        if src.get("meta", {}).get("enabled"):
            data["meta"] = live.fetch_meta(src["meta"], start.date(), end.date())

    # 2. staleness check → aviso no PDF + bloqueio de envio
    warnings, stale = [], False
    max_days = cfg.get("staleness_max_days", 3)
    for name, d in data.items():
        last = pd.Timestamp(d["last_data_date"])
        if (end - last).days > max_days:
            warnings.append(t["stale"].format(src=name.upper(), d=last.date()))
            stale = True

    # 3. charts
    ch = {}
    if data.get("ga4"):
        ch["sessions_trend"] = charts.sessions_trend(
            data["ga4"]["daily_sessions"], data["ga4"]["daily_sessions_prev"], t)
        ch["channels"] = charts.channels_bar(data["ga4"]["channels"])
    if data.get("hubspot"):
        ch["funnel"] = charts.funnel_bar(data["hubspot"]["funnel"])
    if data.get("meta") and len(data["meta"]["campaigns"]):
        ch["spend"] = charts.spend_bar(data["meta"]["campaigns"])

    # 4. render
    outdir = BASE / cfg["output"]["outdir"].format(client_id=cfg["client"]["id"], period=period_key)
    outdir.mkdir(parents=True, exist_ok=True)
    stem = f"{cfg['client']['id']}-{period_key}"

    env = Environment(loader=FileSystemLoader(BASE / "templates"))
    html = env.get_template("report.html.j2").render(
        lang=lang, t=t, client=cfg["client"], branding=cfg["branding"],
        period_label=plabel, warnings=warnings, charts=ch,
        ga4=data.get("ga4"), hubspot=data.get("hubspot"), meta=data.get("meta"),
        commentary=args.commentary.strip(), kpi=kpi_html(cfg["branding"]),
    )

    files = []
    if cfg["output"].get("pdf", True):
        from weasyprint import HTML
        pdf_path = outdir / f"{stem}.pdf"
        HTML(string=html, base_url=str(BASE)).write_pdf(str(pdf_path))
        files.append(pdf_path)
        print(f"  PDF   → {pdf_path}")
    if cfg["output"].get("excel", True):
        xlsx_path = outdir / f"{stem}.xlsx"
        build_excel(xlsx_path, data, t)
        files.append(xlsx_path)
        print(f"  Excel → {xlsx_path}")

    # 5. delivery
    mode = cfg["delivery"]["mode"]
    if args.dry_run or args.no_send or mode == "none":
        print("  envio: desligado (dry-run/no-send/none)")
        return
    if stale:
        print("  envio: BLOQUEADO por staleness — relatório gravado, rever fontes.", file=sys.stderr)
        sys.exit(2)

    to = cfg["delivery"]["review_to"] if mode == "review" else cfg["delivery"]["client_to"]
    subject = f"{t['title']} {cfg['client']['name']} — {plabel}"
    body = (f"{'Draft para revisão' if mode == 'review' else 'Relatório mensal em anexo'} — "
            f"{cfg['client']['name']}, {plabel}.")
    send_email(cfg, subject, body, files, to, cfg["delivery"].get("cc", []))
    print(f"  envio: {mode} → {', '.join(to)}")


if __name__ == "__main__":
    main()
