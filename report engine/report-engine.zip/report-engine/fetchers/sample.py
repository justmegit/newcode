"""Dados sintéticos mas realistas para --dry-run e demos comerciais.

Devolve exatamente a mesma estrutura que os fetchers reais, para que
o resto do pipeline (charts, PDF, Excel) seja testado a 100%.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def fetch_all(period_start: pd.Timestamp, period_end: pd.Timestamp) -> dict:
    rng = np.random.default_rng(42)
    days = pd.date_range(period_start, period_end, freq="D")
    prev_days = pd.date_range(
        period_start - pd.DateOffset(months=1),
        periods=len(days), freq="D",
    )

    def daily_sessions(dates, base):
        weekday_factor = np.where(pd.Series(dates).dt.weekday >= 5, 0.55, 1.0)
        noise = rng.normal(1.0, 0.12, len(dates))
        trend = np.linspace(0.95, 1.1, len(dates))
        return np.maximum(5, (base * weekday_factor * noise * trend)).astype(int)

    cur = pd.DataFrame({"date": days, "sessions": daily_sessions(days, 210)})
    prev = pd.DataFrame({"date": prev_days, "sessions": daily_sessions(prev_days, 188)})

    channels = pd.DataFrame({
        "channel": ["Organic Search", "Paid Social", "Direct", "Referral", "Organic Social", "Email"],
        "sessions": [2612, 1487, 985, 411, 302, 158],
        "users": [2201, 1329, 810, 355, 271, 149],
    })

    top_pages = pd.DataFrame({
        "page": ["/", "/pergolas-bioclimaticas", "/precos", "/projetos", "/contacto"],
        "views": [3105, 2214, 1409, 887, 612],
    })

    campaigns = pd.DataFrame({
        "campaign": ["PT — Pérgulas Verão", "ES — Andalucía Pérgolas", "Remarketing Site"],
        "spend": [612.40, 488.90, 141.30],
        "impressions": [98240, 81410, 45120],
        "clicks": [1520, 1174, 391],
    })
    campaigns["ctr"] = (campaigns.clicks / campaigns.impressions * 100).round(2)
    campaigns["cpc"] = (campaigns.spend / campaigns.clicks).round(2)

    funnel = pd.DataFrame({
        "stage": ["Novos contactos", "Qualificados", "Proposta enviada", "Ganhos"],
        "count": [64, 31, 14, 6],
    })

    return {
        "ga4": {
            "kpis": {
                "sessions": int(cur.sessions.sum()),
                "sessions_prev": int(prev.sessions.sum()),
                "users": 5115, "users_prev": 4620,
                "pageviews": 14930, "pageviews_prev": 13544,
            },
            "daily_sessions": cur,
            "daily_sessions_prev": prev,
            "channels": channels,
            "top_pages": top_pages,
            "last_data_date": period_end,
        },
        "hubspot": {
            "kpis": {
                "new_contacts": 64, "new_contacts_prev": 51,
                "deals_created": 14, "deals_created_prev": 11,
                "deals_won": 6, "deals_won_prev": 4,
                "won_value": 87400.0, "won_value_prev": 52100.0,
            },
            "funnel": funnel,
            "last_data_date": period_end,
        },
        "meta": {
            "kpis": {
                "spend": float(campaigns.spend.sum()),
                "impressions": int(campaigns.impressions.sum()),
                "clicks": int(campaigns.clicks.sum()),
            },
            "campaigns": campaigns,
            "last_data_date": period_end,
        },
    }
