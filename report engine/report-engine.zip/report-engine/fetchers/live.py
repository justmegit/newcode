"""Fetchers reais — APIs diretas, sem dependência de n8n/Sheets.

Requisitos por fonte (uma vez por cliente, no onboarding):
  GA4     : service account JSON + acesso Viewer à property
            pip install google-analytics-data
  HubSpot : private app token (scopes: crm.objects.contacts.read,
            crm.objects.deals.read) em variável de ambiente
  Meta    : system user token de longa duração em variável de ambiente

Cada fetcher devolve a MESMA estrutura que fetchers/sample.py.
`last_data_date` alimenta o bloqueio de staleness no motor.
"""
from __future__ import annotations

import os
from datetime import date

import pandas as pd
import requests


# ── GA4 ────────────────────────────────────────────────────────────
def fetch_ga4(cfg: dict, start: date, end: date) -> dict:
    from google.analytics.data_v1beta import BetaAnalyticsDataClient
    from google.analytics.data_v1beta.types import (
        DateRange, Dimension, Metric, RunReportRequest,
    )

    client = BetaAnalyticsDataClient.from_service_account_file(cfg["credentials_file"])
    prop = cfg["property_id"]
    dr = [DateRange(start_date=str(start), end_date=str(end))]
    dr_prev = [DateRange(
        start_date=str(start - pd.DateOffset(months=1).to_pytimedelta() if False else (pd.Timestamp(start) - pd.DateOffset(months=1)).date()),
        end_date=str((pd.Timestamp(end) - pd.DateOffset(months=1)).date()),
    )]

    def run(dimensions, metrics, date_ranges):
        req = RunReportRequest(
            property=prop,
            dimensions=[Dimension(name=d) for d in dimensions],
            metrics=[Metric(name=m) for m in metrics],
            date_ranges=date_ranges,
        )
        resp = client.run_report(req)
        rows = [
            [d.value for d in r.dimension_values] + [m.value for m in r.metric_values]
            for r in resp.rows
        ]
        return pd.DataFrame(rows, columns=list(dimensions) + list(metrics))

    daily = run(["date"], ["sessions"], dr)
    daily["date"] = pd.to_datetime(daily["date"])
    daily["sessions"] = daily["sessions"].astype(int)
    daily = daily.sort_values("date")

    daily_prev = run(["date"], ["sessions"], dr_prev)
    daily_prev["date"] = pd.to_datetime(daily_prev["date"])
    daily_prev["sessions"] = daily_prev["sessions"].astype(int)
    daily_prev = daily_prev.sort_values("date")

    totals = run([], ["sessions", "totalUsers", "screenPageViews"], dr)
    totals_prev = run([], ["sessions", "totalUsers", "screenPageViews"], dr_prev)

    channels = run(["sessionDefaultChannelGroup"], ["sessions", "totalUsers"], dr)
    channels.columns = ["channel", "sessions", "users"]
    channels[["sessions", "users"]] = channels[["sessions", "users"]].astype(int)
    channels = channels.sort_values("sessions", ascending=False).head(8)

    pages = run(["pagePath"], ["screenPageViews"], dr)
    pages.columns = ["page", "views"]
    pages["views"] = pages["views"].astype(int)
    pages = pages.sort_values("views", ascending=False).head(5)

    t, tp = totals.iloc[0], totals_prev.iloc[0]
    return {
        "kpis": {
            "sessions": int(t["sessions"]), "sessions_prev": int(tp["sessions"]),
            "users": int(t["totalUsers"]), "users_prev": int(tp["totalUsers"]),
            "pageviews": int(t["screenPageViews"]), "pageviews_prev": int(tp["screenPageViews"]),
        },
        "daily_sessions": daily,
        "daily_sessions_prev": daily_prev,
        "channels": channels,
        "top_pages": pages,
        "last_data_date": daily["date"].max(),
    }


# ── HubSpot ────────────────────────────────────────────────────────
def _hs_search(token: str, obj: str, filters: list, total_only=True) -> int:
    r = requests.post(
        f"https://api.hubapi.com/crm/v3/objects/{obj}/search",
        headers={"Authorization": f"Bearer {token}"},
        json={"filterGroups": [{"filters": filters}], "limit": 1},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["total"]


def fetch_hubspot(cfg: dict, start: date, end: date) -> dict:
    token = os.environ[cfg["token_env"]]
    ms = lambda d: str(int(pd.Timestamp(d).timestamp() * 1000))
    p_start = (pd.Timestamp(start) - pd.DateOffset(months=1)).date()
    p_end = (pd.Timestamp(end) - pd.DateOffset(months=1)).date()

    def between(prop, a, b):
        return [
            {"propertyName": prop, "operator": "GTE", "value": ms(a)},
            {"propertyName": prop, "operator": "LTE", "value": ms(pd.Timestamp(b) + pd.Timedelta(days=1))},
        ]

    new_contacts = _hs_search(token, "contacts", between("createdate", start, end))
    new_contacts_prev = _hs_search(token, "contacts", between("createdate", p_start, p_end))
    deals_created = _hs_search(token, "deals", between("createdate", start, end))
    deals_created_prev = _hs_search(token, "deals", between("createdate", p_start, p_end))
    deals_won = _hs_search(token, "deals", between("closedate", start, end) + [
        {"propertyName": "hs_is_closed_won", "operator": "EQ", "value": "true"}])
    deals_won_prev = _hs_search(token, "deals", between("closedate", p_start, p_end) + [
        {"propertyName": "hs_is_closed_won", "operator": "EQ", "value": "true"}])

    # Valor ganho: paginar deals fechados-ganhos do período e somar `amount`
    won_value = 0.0
    r = requests.post(
        "https://api.hubapi.com/crm/v3/objects/deals/search",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "filterGroups": [{"filters": between("closedate", start, end) + [
                {"propertyName": "hs_is_closed_won", "operator": "EQ", "value": "true"}]}],
            "properties": ["amount"], "limit": 100,
        },
        timeout=30,
    )
    r.raise_for_status()
    for d in r.json().get("results", []):
        won_value += float(d["properties"].get("amount") or 0)

    funnel = pd.DataFrame({
        "stage": ["Novos contactos", "Deals criados", "Ganhos"],
        "count": [new_contacts, deals_created, deals_won],
    })

    return {
        "kpis": {
            "new_contacts": new_contacts, "new_contacts_prev": new_contacts_prev,
            "deals_created": deals_created, "deals_created_prev": deals_created_prev,
            "deals_won": deals_won, "deals_won_prev": deals_won_prev,
            "won_value": won_value, "won_value_prev": 0.0,
        },
        "funnel": funnel,
        "last_data_date": pd.Timestamp(end),  # HubSpot não "atrasa"; usar fim do período
    }


# ── Meta Ads ───────────────────────────────────────────────────────
def fetch_meta(cfg: dict, start: date, end: date) -> dict:
    token = os.environ[cfg["token_env"]]
    r = requests.get(
        f"https://graph.facebook.com/v21.0/{cfg['account_id']}/insights",
        params={
            "access_token": token,
            "level": "campaign",
            "fields": "campaign_name,spend,impressions,clicks,ctr,cpc,date_stop",
            "time_range": f'{{"since":"{start}","until":"{end}"}}',
            "limit": 100,
        },
        timeout=30,
    )
    r.raise_for_status()
    rows = r.json().get("data", [])
    if not rows:
        camp = pd.DataFrame(columns=["campaign", "spend", "impressions", "clicks", "ctr", "cpc"])
        last = pd.Timestamp(start)  # sem dados → staleness dispara
    else:
        camp = pd.DataFrame([{
            "campaign": x["campaign_name"],
            "spend": float(x["spend"]),
            "impressions": int(x["impressions"]),
            "clicks": int(x["clicks"]),
            "ctr": round(float(x.get("ctr", 0)), 2),
            "cpc": round(float(x.get("cpc", 0)), 2),
        } for x in rows]).sort_values("spend", ascending=False)
        last = pd.to_datetime(max(x.get("date_stop", str(start)) for x in rows))

    return {
        "kpis": {
            "spend": float(camp.spend.sum()) if len(camp) else 0.0,
            "impressions": int(camp.impressions.sum()) if len(camp) else 0,
            "clicks": int(camp.clicks.sum()) if len(camp) else 0,
        },
        "campaigns": camp,
        "last_data_date": last,
    }
