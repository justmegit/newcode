"""Gráficos matplotlib → PNG (base64) para embeber no HTML do PDF."""
from __future__ import annotations

import base64
import io

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

NAVY, BRASS, STEEL, LIGHT = "#12263A", "#B08D57", "#6E7B8B", "#E9ECEF"


def _style(ax):
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    for spine in ("left", "bottom"):
        ax.spines[spine].set_color(LIGHT)
    ax.tick_params(colors=STEEL, labelsize=8)
    ax.yaxis.grid(True, color=LIGHT, linewidth=0.7)
    ax.set_axisbelow(True)


def _b64(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=160, bbox_inches="tight", transparent=True)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def sessions_trend(cur, prev, labels) -> str:
    fig, ax = plt.subplots(figsize=(7.2, 2.4))
    ax.plot(range(len(prev)), prev["sessions"], color=STEEL, linewidth=1.2,
            linestyle="--", label=labels["prev_month"])
    ax.plot(range(len(cur)), cur["sessions"], color=NAVY, linewidth=2.0,
            label=labels["this_month"])
    ax.fill_between(range(len(cur)), cur["sessions"], color=NAVY, alpha=0.06)
    ax.set_xlim(0, max(len(cur), len(prev)) - 1)
    ax.legend(frameon=False, fontsize=8, loc="upper left", labelcolor=STEEL)
    ax.set_xticks([])
    _style(ax)
    return _b64(fig)


def channels_bar(df) -> str:
    d = df.sort_values("sessions")
    fig, ax = plt.subplots(figsize=(7.2, 0.42 * len(d) + 0.5))
    bars = ax.barh(d["channel"], d["sessions"], color=NAVY, height=0.62)
    bars[-1].set_color(BRASS)  # canal líder em brass
    for b, v in zip(bars, d["sessions"]):
        ax.text(b.get_width() * 1.01, b.get_y() + b.get_height() / 2,
                f"{v:,}".replace(",", " "), va="center", fontsize=8, color=STEEL)
    ax.set_xticks([])
    ax.tick_params(left=False)
    for s in ax.spines.values():
        s.set_visible(False)
    return _b64(fig)


def funnel_bar(df) -> str:
    d = df.iloc[::-1]
    fig, ax = plt.subplots(figsize=(7.2, 0.5 * len(d) + 0.4))
    colors = [BRASS if i == 0 else NAVY for i in range(len(d))][::-1]
    bars = ax.barh(d["stage"], d["count"], color=colors, height=0.6)
    for b, v in zip(bars, d["count"]):
        ax.text(b.get_width() * 1.02, b.get_y() + b.get_height() / 2,
                str(v), va="center", fontsize=9, color=NAVY, fontweight="bold")
    ax.set_xticks([])
    ax.tick_params(left=False)
    for s in ax.spines.values():
        s.set_visible(False)
    return _b64(fig)


def spend_bar(df) -> str:
    d = df.sort_values("spend")
    fig, ax = plt.subplots(figsize=(7.2, 0.5 * len(d) + 0.4))
    bars = ax.barh(d["campaign"], d["spend"], color=NAVY, height=0.6)
    bars[-1].set_color(BRASS)
    ax.xaxis.set_major_formatter(mtick.FormatStrFormatter("€%.0f"))
    for b, v in zip(bars, d["spend"]):
        ax.text(b.get_width() * 1.01, b.get_y() + b.get_height() / 2,
                f"€{v:,.0f}", va="center", fontsize=8, color=STEEL)
    ax.set_xticks([])
    ax.tick_params(left=False)
    for s in ax.spines.values():
        s.set_visible(False)
    return _b64(fig)
